// var el = document.getElementById("brand-title");

// console.log(el);

// console.log(el.innerHTML);
// console.log(el.innerText);

// el.innerText = "안녕하세요 :)"

var el = document.getElementsByClassName('sub-title');

console.log(el);